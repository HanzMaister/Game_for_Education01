# game-for-education
The game for students education